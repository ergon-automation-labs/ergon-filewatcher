{application,hpax,
             [{config_mtime,1780693341},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"Implementation of the HPACK protocol (RFC 7541) for Elixir"},
              {modules,['Elixir.HPAX','Elixir.HPAX.Huffman',
                        'Elixir.HPAX.Table','Elixir.HPAX.Types']},
              {registered,[]},
              {vsn,"1.0.3"}]}.
