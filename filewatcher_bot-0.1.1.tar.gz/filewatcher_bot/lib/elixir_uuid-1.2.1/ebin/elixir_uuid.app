{application,elixir_uuid,
             [{config_mtime,1780693341},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"UUID generator and utilities for Elixir.\n"},
              {modules,['Elixir.UUID']},
              {registered,[]},
              {vsn,"1.2.1"}]}.
