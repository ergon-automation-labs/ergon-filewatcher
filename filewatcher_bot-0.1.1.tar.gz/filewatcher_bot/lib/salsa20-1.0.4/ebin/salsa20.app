{application,salsa20,
             [{config_mtime,1780693341},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"Salsa20 symmetric stream cipher\n"},
              {modules,['Elixir.Salsa20']},
              {registered,[]},
              {vsn,"1.0.4"}]}.
